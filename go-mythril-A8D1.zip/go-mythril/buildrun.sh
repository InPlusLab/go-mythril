go build -o go-mythril main2.go 
./go-mythril > miaomi_latter_skip.txt