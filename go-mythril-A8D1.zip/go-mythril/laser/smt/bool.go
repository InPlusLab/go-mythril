package smt

type Bool struct{}
