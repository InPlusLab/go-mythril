package smt

// #include <stdlib.h>
// #include "./z3/goZ3Config.h"
import "C"

// The implementation is in /smt/z3/array.go.
type Array struct {
}
