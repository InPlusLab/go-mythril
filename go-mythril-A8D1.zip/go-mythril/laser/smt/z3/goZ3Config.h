// install z3 in your machine and replace the path for z3.h
// dynamic lib should be config in config.go
//#include "/usr/local/z3/src/api/z3.h"
//#include "C:/Z3/src/api/z3.h"
#include "/usr/local/z3/src/api/z3.h"